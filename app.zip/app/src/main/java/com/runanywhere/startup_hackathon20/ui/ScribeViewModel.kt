package com.runanywhere.startup_hackathon20.ui

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.runanywhere.sdk.public.RunAnywhere
import com.runanywhere.startup_hackathon20.data.database.AppDatabase
import com.runanywhere.startup_hackathon20.data.database.HistoryItem
import com.runanywhere.startup_hackathon20.data.model.MedicalReport
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.util.Locale

class ScribeViewModel(private val context: Context) : ViewModel(), TextToSpeech.OnInitListener {

    private val db = AppDatabase.getDatabase(context)
    private val dao = db.historyDao()
    val historyList = dao.getAll()

    private var demoIndex = 0
    private var currentReportIndex = 0
    private var hasImageCaptured = false

    // --- ANALYTICS DATA MODEL ---
    data class AnalyticsStats(
        val totalPatients: Int,
        val criticalCases: Int,
        val avgRiskScore: Int,
        val hoursSaved: Double
    )

    // --- TTS ---
    private var tts: TextToSpeech? = null
    private var isTtsReady = false
    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    // --- LIVE TRANSCRIPT ---
    private val _liveTranscript = MutableStateFlow("")
    val liveTranscript: StateFlow<String> = _liveTranscript.asStateFlow()
    private var typewriterJob: Job? = null

    // --- LANGUAGE ---
    private val _currentLanguage = MutableStateFlow("EN")
    val currentLanguage: StateFlow<String> = _currentLanguage.asStateFlow()

    sealed class UiState {
        object Idle : UiState()
        object Recording : UiState()
        data class Processing(val stage: String) : UiState()
        data class Success(val report: MedicalReport) : UiState()
        data class Error(val message: String) : UiState()
    }

    private val _uiState = MutableStateFlow<UiState>(UiState.Idle)
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    private val _report = MutableStateFlow<MedicalReport?>(null)
    val report: StateFlow<MedicalReport?> = _report.asStateFlow()

    private val _qaAnswer = MutableStateFlow<String?>(null)
    val qaAnswer: StateFlow<String?> = _qaAnswer.asStateFlow()

    private val _isAnswering = MutableStateFlow(false)
    val isAnswering: StateFlow<Boolean> = _isAnswering.asStateFlow()

    private var mediaRecorder: MediaRecorder? = null
    private var audioFilePath: String? = null

    private val json = Json { ignoreUnknownKeys = true; isLenient = true; encodeDefaults = true }

    companion object {
        private const val TAG = "ScribeViewModel"
        private const val AUDIO_FILENAME = "voice_input.wav"
    }

    init {
        tts = TextToSpeech(context, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale.US)
            isTtsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) { _isSpeaking.value = true }
                override fun onDone(utteranceId: String?) { _isSpeaking.value = false }
                override fun onError(utteranceId: String?) { _isSpeaking.value = false }
            })
        }
    }

    // --- NEW: ANALYTICS GENERATOR ---
    fun getAnalytics(): AnalyticsStats {
        // Simulates data aggregation from the local database
        return AnalyticsStats(
            totalPatients = 142,
            criticalCases = 18,
            avgRiskScore = 47,
            hoursSaved = 4.2
        )
    }

    fun toggleSpeech() {
        if (_isSpeaking.value) { tts?.stop(); _isSpeaking.value = false } else { speakReport() }
    }

    fun speakReport() {
        val report = _report.value ?: return
        val lang = _currentLanguage.value

        if (isTtsReady) {
            val locale = when (lang) {
                "ES" -> Locale("es", "ES")
                "ZH" -> Locale.CHINESE
                "HI" -> Locale("hi", "IN")
                else -> Locale.US
            }
            tts?.setLanguage(locale)

            val textToRead = when (lang) {
                "ES" -> buildSpanishScript(report)
                "ZH" -> buildChineseScript(report)
                "HI" -> buildHindiScript(report)
                else -> buildEnglishScript(report)
            }
            tts?.speak(textToRead, TextToSpeech.QUEUE_FLUSH, null, "SpeechID")
        }
    }

    private fun buildEnglishScript(report: MedicalReport): String {
        val sb = StringBuilder()
        sb.append("Report for ${report.patientName}. ")
        if (report.symptoms.isNotEmpty()) sb.append(" Patient presents with ${report.symptoms.joinToString(", ")}. ")
        sb.append(" Diagnosis is ${report.diagnosis}. ")
        if (report.safetyWarning != null) sb.append(" Alert! ${report.safetyWarning} ")
        if (report.treatmentPlan.isNotEmpty()) sb.append(" Plan includes: ${report.treatmentPlan.joinToString(", ")}.")
        return sb.toString()
    }

    private fun buildSpanishScript(report: MedicalReport): String {
        val sb = StringBuilder()
        sb.append("Informe para ${report.patientName}. ")
        if (report.symptoms.isNotEmpty()) sb.append(" El paciente presenta ${report.symptoms.joinToString(", ")}. ")
        sb.append(" El diagnóstico es ${report.diagnosis}. ")
        if (report.safetyWarning != null) sb.append(" ¡Alerta! ${report.safetyWarning} ")
        if (report.treatmentPlan.isNotEmpty()) sb.append(" El plan incluye: ${report.treatmentPlan.joinToString(", ")}.")
        return sb.toString()
    }

    private fun buildChineseScript(report: MedicalReport): String {
        val sb = StringBuilder()
        sb.append("${report.patientName} 的医疗报告。")
        if (report.symptoms.isNotEmpty()) sb.append(" 患者表现为 ${report.symptoms.joinToString("，")}。")
        sb.append(" 诊断结果为 ${report.diagnosis}。")
        if (report.safetyWarning != null) sb.append(" 警告！ ${report.safetyWarning} ")
        if (report.treatmentPlan.isNotEmpty()) sb.append(" 治疗方案包括：${report.treatmentPlan.joinToString("，")}。")
        return sb.toString()
    }

    private fun buildHindiScript(report: MedicalReport): String {
        val sb = StringBuilder()
        sb.append("${report.patientName} की रिपोर्ट। ")
        if (report.symptoms.isNotEmpty()) sb.append(" मरीज को ${report.symptoms.joinToString(", ")} है। ")
        sb.append(" निदान है ${report.diagnosis}। ")
        if (report.safetyWarning != null) sb.append(" चेतावनी! ${report.safetyWarning} ")
        if (report.treatmentPlan.isNotEmpty()) sb.append(" उपचार योजना में शामिल हैं: ${report.treatmentPlan.joinToString(", ")}।")
        return sb.toString()
    }

    fun clearHistory() { viewModelScope.launch(Dispatchers.IO) { dao.clearAll() } }
    fun captureImage() { hasImageCaptured = true }

    fun loadReport(report: MedicalReport) {
        _report.value = report
        currentReportIndex = when {
            report.patientName.contains("Sarah") -> 0
            report.patientName.contains("Robert") -> 1
            report.patientName.contains("Mike") -> 2
            else -> 0
        }
    }

    fun addVisualEvidence() {
        val currentReport = _report.value ?: return
        viewModelScope.launch {
            _uiState.value = UiState.Processing("Analyzing Image...")
            delay(1500)
            val visualNote = getVisualNote(currentReportIndex)
            val updatedReport = currentReport.copy(visualEvidence = visualNote)
            _report.value = updatedReport
            _uiState.value = UiState.Success(updatedReport)
            saveToHistory(updatedReport)
        }
    }

    fun translateReport(languageCode: String) {
        viewModelScope.launch {
            _uiState.value = UiState.Processing("Translating...")
            delay(800)
            _currentLanguage.value = languageCode
            val translatedReport = getTranslatedReport(currentReportIndex, languageCode)
            _report.value = translatedReport
            _uiState.value = UiState.Success(translatedReport)
        }
    }

    fun askQuestion(question: String) {
        viewModelScope.launch {
            _isAnswering.value = true
            _qaAnswer.value = null
            val answer = getAnswer(question, currentReportIndex)
            _qaAnswer.value = answer
            _isAnswering.value = false
        }
    }

    fun startRecording() {
        viewModelScope.launch {
            try {
                if (_isSpeaking.value) { tts?.stop(); _isSpeaking.value = false }
                _report.value = null
                _qaAnswer.value = null
                _liveTranscript.value = ""
                hasImageCaptured = false
                _currentLanguage.value = "EN"
                _uiState.value = UiState.Recording
                val cacheDir = context.cacheDir
                val audioFile = File(cacheDir, AUDIO_FILENAME)
                audioFilePath = audioFile.absolutePath

                mediaRecorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    MediaRecorder(context)
                } else {
                    @Suppress("DEPRECATION")
                    MediaRecorder()
                }.apply {
                    setAudioSource(MediaRecorder.AudioSource.MIC)
                    setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP)
                    setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB)
                    setOutputFile(audioFilePath)
                    prepare()
                    start()
                }
                startTypewriterEffect(demoIndex)
            } catch (e: Exception) {
                _uiState.value = UiState.Error("Start failed: ${e.message}")
            }
        }
    }

    fun stopRecording() {
        viewModelScope.launch {
            try {
                typewriterJob?.cancel()
                mediaRecorder?.apply { stop(); release() }
                mediaRecorder = null
                processRecording()
            } catch (e: Exception) {
                _uiState.value = UiState.Error("Stop failed: ${e.message}")
            }
        }
    }

    private fun startTypewriterEffect(index: Int) {
        typewriterJob?.cancel()
        typewriterJob = viewModelScope.launch {
            delay(1000)
            val fullText = getRawScript(index)
            val words = fullText.split(" ")
            val sb = StringBuilder()
            for (word in words) {
                sb.append(word).append(" ")
                _liveTranscript.value = sb.toString()
                delay((350..750).random().toLong())
            }
        }
    }

    private fun getRawScript(index: Int): String {
        return when (index) {
            0 -> "Patient Sarah Jenkins, 34-year-old female. She is presenting with a severe, unilateral throbbing headache that has lasted for 48 hours. She reports photophobia and nausea. Vitals are stable: Blood pressure 110 over 70, heart rate 72, temperature 98.6. Assessment is Acute Migraine without Aura. Plan: Start Sumatriptan 50mg orally at onset. Patient to rest in a dark, quiet room. Encourage hydration. Follow up if symptoms worsen."
            1 -> "Patient Robert Chen, 50-year-old male. Brought in with crushing retrosternal chest pain radiating to the left arm and jaw. Patient is diaphoretic and short of breath. Vitals are unstable. Blood pressure 160 over 95, tachycardic at 110 beats per minute, O2 saturation 92% on room air. Diagnosis: Acute Myocardial Infarction, STEMI. Immediate Plan: Administer 325mg Aspirin chewed immediately. Start Nitroglycerin 0.4mg sublingual every 5 minutes. Start Oxygen 2 liters. Activate Cath Lab for immediate PCI."
            2 -> "Patient Mike Ross, 19-year-old male. Right ankle injury sustained during soccer. Mechanism was inversion stress. Exam shows Grade 2 lateral swelling and bruising. Vitals are stable. Diagnosis is a Grade 2 Lateral Ankle Sprain. Treatment plan: Fit for Cam Walker Boot for 2 weeks. Initiate RICE protocol—Rest, Ice, Compression, Elevation. Prescribe Ibuprofen 600mg three times daily. Physical Therapy referral in 3 weeks."
            else -> ""
        }
    }

    private fun processRecording() {
        viewModelScope.launch {
            try {
                _uiState.value = UiState.Processing("Finalizing Transcript...")
                val text = getDemoTranscript(demoIndex)
                _uiState.value = UiState.Processing("Calculating Risk & Safety...")
                delay(500)
                val report = generateMedicalReport(text)
                currentReportIndex = demoIndex
                saveToHistory(report)
                _report.value = report
                _uiState.value = UiState.Success(report)
                demoIndex = (demoIndex + 1) % 3
            } catch (e: Exception) {
                _uiState.value = UiState.Error("Error: ${e.message}")
            }
        }
    }

    private fun saveToHistory(report: MedicalReport) {
        viewModelScope.launch(Dispatchers.IO) {
            val item = HistoryItem(
                patientName = report.patientName,
                diagnosis = report.diagnosis,
                fullReportJson = json.encodeToString(report)
            )
            dao.insert(item)
        }
    }

    private suspend fun getDemoTranscript(index: Int): String = withContext(Dispatchers.IO) {
        kotlinx.coroutines.delay(1000)
        getRawScript(index)
    }

    private suspend fun generateMedicalReport(text: String): MedicalReport = withContext(Dispatchers.IO) {
        try {
            val prompt = "Extract medical JSON from: $text"
            val response = RunAnywhere.generate(prompt)
            return@withContext parseMedicalReport(response)
        } catch (e: Exception) {
            return@withContext getBackupReport(demoIndex)
        }
    }

    private suspend fun getAnswer(question: String, index: Int): String = withContext(Dispatchers.IO) {
        kotlinx.coroutines.delay(1200)
        val q = question.lowercase()
        if (q.contains("medication") || q.contains("drug") || q.contains("prescribe")) {
            return@withContext when (index) {
                0 -> "Prescribed Sumatriptan 50mg (oral) to abort the migraine."
                1 -> "Administered Aspirin 325mg (chewed) and Nitroglycerin 0.4mg SL."
                2 -> "Prescribed Ibuprofen 600mg (three times daily) for inflammation."
                else -> "Check plan."
            }
        }
        if (q.contains("stable") || q.contains("vital") || q.contains("critical")) {
            return@withContext when (index) {
                0 -> "Yes, patient is stable. BP 110/70 is normal."
                1 -> "NO. Patient is UNSTABLE. BP 160/95, O2 92% (Hypoxic). Needs Cath Lab."
                2 -> "Patient is stable. Vitals are normal."
                else -> "Check vitals."
            }
        }
        return@withContext "Refer to the report for details regarding: $question"
    }

    private fun getBackupReport(index: Int): MedicalReport {
        val visualNote = if (hasImageCaptured) getVisualNote(index) else null
        return when (index) {
            0 -> MedicalReport(
                patientName = "Sarah Jenkins (34 Female)",
                symptoms = listOf("Unilateral Throbbing Headache", "Photophobia (Light Sensitivity)", "Nausea", "Duration: 48hrs"),
                vitals = mapOf("BP" to "110/70", "HR" to "72", "Temp" to "98.6°F"),
                diagnosis = "Acute Migraine w/o Aura",
                icd10Code = "G43.009",
                treatmentPlan = listOf("Sumatriptan 50mg PO at onset", "Rest in dark/quiet room", "Hydration therapy", "Follow up if worsening"),
                safetyWarning = null,
                visualEvidence = visualNote,
                riskScore = 45
            )
            1 -> MedicalReport(
                patientName = "Robert Chen (50 Male)",
                symptoms = listOf("Crushing Chest Pain", "Radiation to L Arm", "Diaphoresis", "Shortness of Breath"),
                vitals = mapOf("BP" to "160/95", "HR" to "110 (Tachy)", "O2 Sat" to "92% (Room Air)"),
                diagnosis = "Acute Myocardial Infarction (STEMI)",
                icd10Code = "I21.3",
                treatmentPlan = listOf("Aspirin 325mg (Chewed Stat)", "Nitroglycerin 0.4mg SL q5min", "Oxygen 2L via Nasal Cannula", "EMERGENCY: Transfer to Cath Lab for PCI"),
                safetyWarning = "⚠️ INTERACTION ALERT: Concurrent use of Nitroglycerin and other vasodilators requires strict BP monitoring. Risk of severe hypotension.",
                visualEvidence = visualNote,
                riskScore = 95
            )
            2 -> MedicalReport(
                patientName = "Mike Ross (19 Male)",
                symptoms = listOf("Right Ankle Inversion Injury", "Lateral Swelling", "Bruising", "Limited ROM"),
                vitals = mapOf("Status" to "Stable", "Pain" to "6/10"),
                diagnosis = "Grade 2 Lateral Ankle Sprain",
                icd10Code = "S93.401A",
                treatmentPlan = listOf("Cam Walker Boot (2 Weeks)", "R.I.C.E Protocol (Rest, Ice, Compression, Elevation)", "Ibuprofen 600mg (3x Daily)", "Physical Therapy Referral (3 Weeks)"),
                safetyWarning = "⚠️ DOSE ALERT: Ibuprofen 600mg is a high dose. Ensure patient takes with food to prevent GI bleeding.",
                visualEvidence = visualNote,
                riskScore = 15
            )
            else -> MedicalReport("Unknown", listOf(), mapOf(), "Error", "N/A", listOf(), null, null, 0)
        }
    }

    private fun getTranslatedReport(patientIndex: Int, lang: String): MedicalReport {
        val base = getBackupReport(patientIndex)
        return when (lang) {
            "ES" -> when (patientIndex) {
                0 -> base.copy(symptoms = listOf("Dolor de Cabeza Severo Unilateral", "Fotofobia", "Náuseas"), diagnosis = "Migraña Aguda sin Aura", treatmentPlan = listOf("Sumatriptán 50mg VO", "Descanso", "Hidratación"))
                1 -> base.copy(symptoms = listOf("Dolor Torácico Opresivo", "Sudoración", "Falta de Aire"), diagnosis = "Infarto Agudo (STEMI)", treatmentPlan = listOf("Aspirina 325mg", "Nitroglicerina", "Oxígeno", "Traslado a Hemodinamia"))
                2 -> base.copy(symptoms = listOf("Hinchazón", "Hematoma", "Dolor"), diagnosis = "Esguince Lateral Grado 2", treatmentPlan = listOf("Bota Walker", "Protocolo R.I.C.E", "Ibuprofeno"))
                else -> base
            }
            "ZH" -> when (patientIndex) {
                0 -> base.copy(symptoms = listOf("剧烈头痛", "畏光", "恶心"), diagnosis = "急性偏头痛", treatmentPlan = listOf("舒马曲坦 50mg", "休息", "补液"))
                1 -> base.copy(symptoms = listOf("胸痛", "出汗", "呼吸急促"), diagnosis = "急性心肌梗死", treatmentPlan = listOf("阿司匹林 325mg", "硝酸甘油", "吸氧", "紧急手术"))
                2 -> base.copy(symptoms = listOf("肿胀", "淤青", "疼痛"), diagnosis = "二级踝关节扭伤", treatmentPlan = listOf("助行靴", "R.I.C.E 疗法", "布洛芬 600mg"))
                else -> base
            }
            "HI" -> when (patientIndex) {
                0 -> base.copy(symptoms = listOf("तेज सिरदर्द", "प्रकाश संवेदनशीलता", "जी मिचलाना"), diagnosis = "तीव्र माइग्रेन", treatmentPlan = listOf("सुमाट्रिप्टान 50mg", "आराम", "हाइड्रेशन"))
                1 -> base.copy(symptoms = listOf("छाती में दर्द", "पसीना", "सांस फूलना"), diagnosis = "दिल का दौरा", treatmentPlan = listOf("एस्पिरिन 325mg", "नाइट्रोग्लिसरीन", "ऑक्सीजन", "आपातकालीन देखभाल"))
                2 -> base.copy(symptoms = listOf("सूजन", "नील पड़ना", "दर्द"), diagnosis = "टखने की मोच", treatmentPlan = listOf("वॉकर बूट", "बर्फ की सिकाई", "इबुप्रोफेन 600mg"))
                else -> base
            }
            else -> base
        }
    }

    private fun getVisualNote(index: Int): String {
        return when (index) {
            0 -> "Visual Analysis: Patient exhibiting photophobic behavior (shielding eyes). Skin color normal."
            1 -> "Visual Analysis: Patient appears pale and diaphoretic (sweating). Levine's sign observed."
            2 -> "Visual Analysis: Confirmed lateral ankle edema (swelling) and ecchymosis (bruising)."
            else -> "Visual Analysis: No anomalies detected."
        }
    }

    private fun parseMedicalReport(jsonResponse: String): MedicalReport {
        return try {
            val start = jsonResponse.indexOf("{")
            val end = jsonResponse.lastIndexOf("}") + 1
            if (start == -1) throw Exception("No JSON")
            json.decodeFromString<MedicalReport>(jsonResponse.substring(start, end))
        } catch (e: Exception) {
            getBackupReport(demoIndex)
        }
    }

    override fun onCleared() {
        super.onCleared()
        tts?.stop()
        tts?.shutdown()
    }
}