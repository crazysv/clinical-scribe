package com.runanywhere.startup_hackathon20

import android.Manifest
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.viewmodel.compose.viewModel
import com.runanywhere.startup_hackathon20.data.database.HistoryItem
import com.runanywhere.startup_hackathon20.data.model.MedicalReport
import com.runanywhere.startup_hackathon20.ui.PdfHelper
import com.runanywhere.startup_hackathon20.ui.QrHelper
import com.runanywhere.startup_hackathon20.ui.ScribeViewModel
import com.runanywhere.startup_hackathon20.ui.theme.Startup_hackathon20Theme
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.text.SimpleDateFormat
import java.util.*

// --- CUSTOM MEDICAL COLORS ---
object MedColors {
    val Primary = Color(0xFF2563EB)
    val PrimaryDark = Color(0xFF1E40AF)
    val Accent = Color(0xFF00C853)
    val Alert = Color(0xFFEF4444)
    val BackgroundTop = Color(0xFFF8FAFC)
    val BackgroundBottom = Color(0xFFE0F2FE)
    val TextDark = Color(0xFF1E293B)
    val TextGray = Color(0xFF64748B)
    val SurfaceGray = Color(0xFFF1F5F9)
}

// --- UI TRANSLATION DICTIONARY ---
object UiTranslations {
    fun get(key: String, lang: String): String {
        return when(lang) {
            "ES" -> when(key) { "title" -> "Informe Médico"; "diagnosis" -> "Diagnóstico y Facturación"; "symptoms" -> "Síntomas"; "vitals" -> "Signos Vitales"; "plan" -> "Plan de Tratamiento"; "ask" -> "Preguntar al Asistente"; else -> key }
            "ZH" -> when(key) { "title" -> "医疗报告"; "diagnosis" -> "诊断与计费"; "symptoms" -> "症状"; "vitals" -> "生命体征"; "plan" -> "治疗方案"; "ask" -> "询问AI助手"; else -> key }
            "HI" -> when(key) { "title" -> "चिकित्सा रिपोर्ट"; "diagnosis" -> "निदान और बिलिंग"; "symptoms" -> "लक्षण"; "vitals" -> "महत्वपूर्ण संकेत"; "plan" -> "उपचार योजना"; "ask" -> "AI सहायक से पूछें"; else -> key }
            else -> when(key) { "title" -> "Medical Report"; "diagnosis" -> "Diagnosis & Billing"; "symptoms" -> "Symptoms"; "vitals" -> "Vital Signs"; "plan" -> "Treatment Plan"; "ask" -> "Ask the AI Assistant"; else -> key }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            Startup_hackathon20Theme {
                Box(modifier = Modifier.fillMaxSize().background(Brush.verticalGradient(colors = listOf(MedColors.BackgroundTop, MedColors.BackgroundBottom)))) {
                    ScribeScreen()
                }
            }
        }
    }
}

@Composable
fun ScribeScreen() {
    val context = LocalContext.current
    val viewModel: ScribeViewModel = viewModel(factory = ScribeViewModelFactory(context))

    val uiState by viewModel.uiState.collectAsState()
    val report by viewModel.report.collectAsState()
    val history by viewModel.historyList.collectAsState(initial = emptyList())
    val liveTranscript by viewModel.liveTranscript.collectAsState()
    val isSpeaking by viewModel.isSpeaking.collectAsState()

    var showHistory by remember { mutableStateOf(false) }
    var showLanguageMenu by remember { mutableStateOf(false) }
    var showQr by remember { mutableStateOf(false) }
    var showAnalytics by remember { mutableStateOf(false) }
    var selectedHistoryItem by remember { mutableStateOf<MedicalReport?>(null) }

    val permissionLauncher = rememberLauncherForActivityResult(contract = ActivityResultContracts.RequestPermission()) { }
    val cameraLauncher = rememberLauncherForActivityResult(contract = ActivityResultContracts.TakePicturePreview()) { bitmap ->
        if (bitmap != null) {
            Toast.makeText(context, "Processing Image...", Toast.LENGTH_SHORT).show()
            viewModel.captureImage()
            viewModel.addVisualEvidence()
        }
    }
    LaunchedEffect(Unit) { permissionLauncher.launch(Manifest.permission.RECORD_AUDIO) }

    if (showQr && report != null) {
        val jsonString = remember(report) { Json { encodeDefaults = true; prettyPrint = true }.encodeToString(report!!) }
        QrDialog(data = jsonString, onDismiss = { showQr = false })
    }

    if (showAnalytics) {
        AnalyticsDialog(onDismiss = { showAnalytics = false })
    }

    if (selectedHistoryItem != null) {
        Dialog(onDismissRequest = { selectedHistoryItem = null }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Box(modifier = Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.White, MedColors.BackgroundBottom)))) {
                Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        SmallFloatingActionButton(onClick = { selectedHistoryItem = null }, containerColor = Color.White) { Icon(Icons.Rounded.Close, "Close") }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    ResultCard(report = selectedHistoryItem!!, viewModel = viewModel, onOpenCamera = { })
                }
            }
        }
    }

    if (showHistory) {
        HistoryScreen(history = history, onClose = { showHistory = false }, onClear = { viewModel.clearHistory() }, onItemClick = { historyItem ->
            try {
                val parsedReport = Json { ignoreUnknownKeys = true }.decodeFromString<MedicalReport>(historyItem.fullReportJson)
                viewModel.loadReport(parsedReport)
                selectedHistoryItem = parsedReport
            } catch (e: Exception) { }
        })
    } else {
        Scaffold(
            containerColor = Color.Transparent,
            topBar = {
                GlassTopBar(
                    onLanguageClick = { showLanguageMenu = true },
                    onHistoryClick = { showHistory = true },
                    onSpeakClick = { viewModel.toggleSpeech() },
                    onQrClick = { showQr = true },
                    onAnalyticsClick = { showAnalytics = true },
                    showReportActions = report != null,
                    isSpeaking = isSpeaking,
                    languageMenuExpanded = showLanguageMenu,
                    onLanguageDismiss = { showLanguageMenu = false },
                    onLanguageSelect = { viewModel.translateReport(it); showLanguageMenu = false }
                )
            }
        ) { paddingValues ->
            Box(modifier = Modifier.fillMaxSize().padding(paddingValues)) {
                Column(
                    modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Spacer(modifier = Modifier.height(20.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.MedicalServices, null, tint = MedColors.Primary, modifier = Modifier.size(32.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Clinical Scribe", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = MedColors.TextDark)
                    }
                    Spacer(modifier = Modifier.height(24.dp))

                    AnimatedVisibility(visible = uiState is ScribeViewModel.UiState.Recording, enter = fadeIn() + expandVertically(), exit = fadeOut() + shrinkVertically()) {
                        GlassCard(modifier = Modifier.fillMaxWidth().padding(bottom = 24.dp)) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Color.Red))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("LISTENING (ON-DEVICE)", fontSize = 11.sp, color = MedColors.Alert, fontWeight = FontWeight.Bold)
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(text = liveTranscript, fontSize = 18.sp, color = MedColors.TextDark, lineHeight = 26.sp, fontWeight = FontWeight.Medium)
                            }
                        }
                    }

                    MicButton(uiState = uiState, onStartRecording = { viewModel.startRecording() }, onStopRecording = { viewModel.stopRecording() })

                    AnimatedVisibility(visible = uiState is ScribeViewModel.UiState.Recording) {
                        Spacer(modifier = Modifier.height(16.dp))
                        FilledTonalButton(onClick = { cameraLauncher.launch(null) }, colors = ButtonDefaults.filledTonalButtonColors(containerColor = Color.White), elevation = ButtonDefaults.filledTonalButtonElevation(4.dp)) {
                            Icon(Icons.Rounded.CameraAlt, null, tint = MedColors.Primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Capture Visual Evidence")
                        }
                    }

                    Spacer(modifier = Modifier.height(32.dp))
                    AnimatedVisibility(visible = report != null, enter = slideInVertically(initialOffsetY = { it / 2 }) + fadeIn(animationSpec = tween(500)), exit = fadeOut()) {
                        report?.let { ResultCard(report = it, viewModel = viewModel, onOpenCamera = { cameraLauncher.launch(null) }) }
                    }
                    Spacer(modifier = Modifier.height(40.dp))
                }
            }
        }
    }
}

@Composable
fun GlassTopBar(
    onLanguageClick: () -> Unit,
    onHistoryClick: () -> Unit,
    onSpeakClick: () -> Unit,
    onQrClick: () -> Unit,
    onAnalyticsClick: () -> Unit,
    showReportActions: Boolean,
    isSpeaking: Boolean,
    languageMenuExpanded: Boolean,
    onLanguageDismiss: () -> Unit,
    onLanguageSelect: (String) -> Unit
) {
    Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp).padding(top = 24.dp).clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.85f)).padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box {
                IconButton(onClick = onLanguageClick) { Icon(Icons.Rounded.Translate, null, tint = MedColors.Primary) }
                DropdownMenu(expanded = languageMenuExpanded, onDismissRequest = onLanguageDismiss) {
                    DropdownMenuItem(text = { Text("English") }, onClick = { onLanguageSelect("EN") })
                    DropdownMenuItem(text = { Text("Español") }, onClick = { onLanguageSelect("ES") })
                    DropdownMenuItem(text = { Text("中文") }, onClick = { onLanguageSelect("ZH") })
                    DropdownMenuItem(text = { Text("हिन्दी") }, onClick = { onLanguageSelect("HI") })
                }
            }
            if (showReportActions) {
                IconButton(onClick = onSpeakClick) { Icon(if (isSpeaking) Icons.Rounded.StopCircle else Icons.Rounded.VolumeUp, null, tint = if(isSpeaking) MedColors.Alert else MedColors.Primary) }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onAnalyticsClick) { Icon(Icons.Default.BarChart, null, tint = MedColors.Primary) }
            if (showReportActions) { IconButton(onClick = onQrClick) { Icon(Icons.Rounded.QrCode2, null, tint = MedColors.Primary) } }
            IconButton(onClick = onHistoryClick) { Icon(Icons.Rounded.History, null, tint = MedColors.Primary) }
        }
    }
}

@Composable
fun AnalyticsDialog(onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(8.dp), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(24.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.BarChart, null, tint = MedColors.Primary, modifier = Modifier.size(28.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Text("Shift Analytics", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MedColors.TextDark)
                }
                Spacer(modifier = Modifier.height(24.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    StatBox("Patients", "142", Color(0xFFE0F2FE), Color(0xFF0284C7))
                    StatBox("Critical", "18", Color(0xFFFEE2E2), Color(0xFFDC2626))
                }
                Spacer(modifier = Modifier.height(12.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    StatBox("Avg Risk", "47%", Color(0xFFFEF3C7), Color(0xFFD97706))
                    StatBox("Time Saved", "4.2h", Color(0xFFDCFCE7), Color(0xFF16A34A))
                }

                Spacer(modifier = Modifier.height(24.dp))
                Text("Top Diagnoses (Last 24h)", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MedColors.TextGray)
                Spacer(modifier = Modifier.height(12.dp))

                DiagnosisBar("Acute Migraine", 0.8f, MedColors.Primary)
                DiagnosisBar("STEMI", 0.3f, MedColors.Alert)
                DiagnosisBar("Lateral Sprain", 0.5f, MedColors.Accent)

                Spacer(modifier = Modifier.height(24.dp))
                Button(onClick = onDismiss, modifier = Modifier.fillMaxWidth(), shape = CircleShape, colors = ButtonDefaults.buttonColors(containerColor = MedColors.TextDark)) {
                    Text("Close Dashboard")
                }
            }
        }
    }
}

@Composable
fun StatBox(label: String, value: String, bgColor: Color, textColor: Color) {
    Card(colors = CardDefaults.cardColors(containerColor = bgColor), shape = RoundedCornerShape(16.dp), modifier = Modifier.width(140.dp)) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(value, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = textColor)
            Text(label, fontSize = 12.sp, fontWeight = FontWeight.Medium, color = textColor.copy(alpha = 0.8f))
        }
    }
}

@Composable
fun DiagnosisBar(label: String, percent: Float, color: Color) {
    Column(modifier = Modifier.padding(bottom = 8.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, fontSize = 12.sp, color = MedColors.TextDark)
            Text("${(percent * 100).toInt()}%", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = color)
        }
        Spacer(modifier = Modifier.height(4.dp))
        LinearProgressIndicator(progress = { percent }, modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(50)), color = color, trackColor = Color(0xFFF1F5F9))
    }
}

@Composable
fun ResultCard(report: MedicalReport, viewModel: ScribeViewModel, onOpenCamera: () -> Unit) {
    val context = LocalContext.current
    val qaAnswer by viewModel.qaAnswer.collectAsState()
    val isAnswering by viewModel.isAnswering.collectAsState()
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    var questionText by remember { mutableStateOf("") }

    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(12.dp)) {
        Column(modifier = Modifier.padding(24.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(UiTranslations.get("title", currentLanguage).uppercase(), fontSize = 12.sp, color = MedColors.TextGray, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    Text(report.patientName, fontSize = 24.sp, fontWeight = FontWeight.Black, color = MedColors.TextDark)
                }
                IconButton(onClick = onOpenCamera) { Icon(Icons.Rounded.CameraAlt, null, tint = MedColors.Primary) }
                IconButton(onClick = { PdfHelper.generateAndSharePdf(context, report) }) { Icon(Icons.Rounded.Share, null, tint = MedColors.Primary) }
            }

            Spacer(modifier = Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("AI TRIAGE SCORE", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MedColors.TextGray)
                Spacer(modifier = Modifier.weight(1f))
                Text("${report.riskScore}/100", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MedColors.TextDark)
            }
            Spacer(modifier = Modifier.height(6.dp))
            val riskColor = when { report.riskScore >= 80 -> MedColors.Alert; report.riskScore >= 40 -> Color(0xFFF59E0B); else -> MedColors.Accent }
            LinearProgressIndicator(progress = { report.riskScore / 100f }, modifier = Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(50)), color = riskColor, trackColor = Color(0xFFF1F5F9))

            Spacer(modifier = Modifier.height(24.dp))
            Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF6FF)), shape = RoundedCornerShape(16.dp), border = BorderStroke(1.dp, Color(0xFFBFDBFE))) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(UiTranslations.get("diagnosis", currentLanguage), fontSize = 12.sp, color = MedColors.Primary, fontWeight = FontWeight.Bold)
                    Text(report.diagnosis, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MedColors.PrimaryDark)
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(color = MedColors.Accent, shape = RoundedCornerShape(8.dp)) { Text("ICD-10: ${report.icd10Code}", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) }
                }
            }

            if (report.visualEvidence != null) {
                Spacer(modifier = Modifier.height(12.dp))
                GlassCard(color = Color(0xFFECFEFF), borderColor = Color(0xFF06B6D4)) {
                    Row(verticalAlignment = Alignment.Top, modifier = Modifier.padding(12.dp)) {
                        Icon(Icons.Rounded.CameraAlt, null, tint = Color(0xFF0891B2), modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(report.visualEvidence, color = Color(0xFF0E7490), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            if (report.safetyWarning != null) {
                Spacer(modifier = Modifier.height(12.dp))
                GlassCard(color = Color(0xFFFEF2F2), borderColor = MedColors.Alert) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(12.dp)) {
                        Icon(Icons.Rounded.Warning, null, tint = MedColors.Alert, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(report.safetyWarning, color = Color(0xFF991B1B), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // FIXED: ROW Alignment
            if (report.symptoms.isNotEmpty()) {
                SectionHeader(UiTranslations.get("symptoms", currentLanguage))
                report.symptoms.forEach { symptom ->
                    Row(verticalAlignment = Alignment.Top, modifier = Modifier.padding(bottom = 6.dp)) {
                        Icon(Icons.Rounded.FiberManualRecord, null, modifier = Modifier.size(10.dp).padding(top=4.dp), tint = MedColors.Primary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(symptom, fontSize = 15.sp, color = MedColors.TextDark)
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }

            if (report.vitals.isNotEmpty()) {
                SectionHeader(UiTranslations.get("vitals", currentLanguage))
                @OptIn(ExperimentalLayoutApi::class)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    report.vitals.forEach { (key, value) ->
                        Surface(color = MedColors.SurfaceGray, shape = RoundedCornerShape(8.dp), modifier = Modifier.padding(bottom = 8.dp)) {
                            Row(modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
                                Text(formatVitalName(key), fontSize = 13.sp, color = MedColors.TextGray)
                                Text(": ", fontSize = 13.sp, color = MedColors.TextGray)
                                Text(value, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MedColors.TextDark)
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }

            SectionHeader(UiTranslations.get("plan", currentLanguage))
            report.treatmentPlan.forEach { plan ->
                Row(verticalAlignment = Alignment.Top, modifier = Modifier.padding(bottom = 8.dp)) {
                    Box(modifier = Modifier.size(20.dp).background(MedColors.Primary.copy(alpha = 0.1f), CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Check, null, tint = MedColors.Primary, modifier = Modifier.size(12.dp)) }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(plan, fontSize = 15.sp, color = MedColors.TextDark, lineHeight = 22.sp)
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
            HorizontalDivider(color = Color(0xFFE2E8F0))
            Spacer(modifier = Modifier.height(16.dp))

            Text(UiTranslations.get("ask", currentLanguage), fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MedColors.Primary)
            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = questionText,
                onValueChange = { questionText = it },
                placeholder = { Text("Ask about this patient...", fontSize = 14.sp, color = Color.Gray) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = MedColors.Primary, unfocusedBorderColor = Color(0xFFE2E8F0), focusedContainerColor = Color.White, unfocusedContainerColor = Color(0xFFFAFAFA)),
                trailingIcon = {
                    IconButton(onClick = { if (questionText.isNotBlank()) viewModel.askQuestion(questionText) }, enabled = !isAnswering, modifier = Modifier.background(MedColors.Primary, CircleShape).size(32.dp)) {
                        if (isAnswering) CircularProgressIndicator(color = Color.White, modifier = Modifier.size(16.dp)) else Icon(Icons.Rounded.Send, null, tint = Color.White, modifier = Modifier.size(16.dp))
                    }
                }
            )

            AnimatedVisibility(visible = qaAnswer != null) {
                Card(modifier = Modifier.fillMaxWidth().padding(top = 12.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFF0FDF4)), shape = RoundedCornerShape(12.dp)) {
                    Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.Top) {
                        Text("🤖", fontSize = 16.sp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(qaAnswer ?: "", fontSize = 14.sp, color = Color(0xFF14532D), lineHeight = 20.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun GlassCard(modifier: Modifier = Modifier, color: Color = Color.White.copy(alpha = 0.7f), borderColor: Color = Color.Transparent, content: @Composable () -> Unit) { Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = color), shape = RoundedCornerShape(16.dp), border = BorderStroke(1.dp, borderColor)) { content() } }

@Composable
fun MicButton(uiState: ScribeViewModel.UiState, onStartRecording: () -> Unit, onStopRecording: () -> Unit) {
    val isRecording = uiState is ScribeViewModel.UiState.Recording
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val scale by infiniteTransition.animateFloat(initialValue = 1f, targetValue = if (isRecording) 1.2f else 1f, animationSpec = infiniteRepeatable(tween(1000), RepeatMode.Reverse), label = "scale")
    val alpha by infiniteTransition.animateFloat(initialValue = 0.5f, targetValue = if (isRecording) 0f else 0.5f, animationSpec = infiniteRepeatable(tween(1000), RepeatMode.Reverse), label = "alpha")
    Box(contentAlignment = Alignment.Center, modifier = Modifier.size(120.dp)) {
        if (isRecording) Box(modifier = Modifier.size(120.dp).scale(scale).clip(CircleShape).background(MedColors.Alert.copy(alpha = alpha)))
        Button(onClick = { if (isRecording) onStopRecording() else onStartRecording() }, modifier = Modifier.size(90.dp), shape = CircleShape, colors = ButtonDefaults.buttonColors(containerColor = if (isRecording) MedColors.Alert else MedColors.Primary), elevation = ButtonDefaults.buttonElevation(8.dp)) { Icon(imageVector = if (isRecording) Icons.Rounded.Stop else Icons.Rounded.Mic, contentDescription = null, modifier = Modifier.size(40.dp), tint = Color.White) }
    }
    Spacer(modifier = Modifier.height(8.dp))
    Text(text = if (isRecording) "Recording..." else "Tap to Listen", color = if (isRecording) MedColors.Alert else MedColors.TextGray, fontWeight = FontWeight.Bold, fontSize = 14.sp)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(history: List<HistoryItem>, onClose: () -> Unit, onClear: () -> Unit, onItemClick: (HistoryItem) -> Unit) {
    Scaffold(topBar = { CenterAlignedTopAppBar(title = { Text("History", fontWeight = FontWeight.Bold) }, navigationIcon = { IconButton(onClick = onClose) { Icon(Icons.Rounded.Close, null) } }, actions = { IconButton(onClick = onClear) { Icon(Icons.Rounded.Delete, null, tint = MedColors.Alert) } }) }) { padding ->
        LazyColumn(contentPadding = padding, modifier = Modifier.fillMaxSize().background(MedColors.BackgroundTop).padding(horizontal = 16.dp)) {
            items(history) { item ->
                Card(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp).clickable { onItemClick(item) }, colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(2.dp)) {
                    Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(40.dp).clip(CircleShape).background(MedColors.BackgroundBottom), contentAlignment = Alignment.Center) { Text(item.patientName.take(1), fontWeight = FontWeight.Bold, color = MedColors.Primary) }
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) { Text(item.patientName, fontWeight = FontWeight.Bold, fontSize = 16.sp); Text(SimpleDateFormat("MMM dd, HH:mm", Locale.getDefault()).format(Date(item.timestamp)), fontSize = 12.sp, color = MedColors.TextGray) }
                        Icon(Icons.Rounded.ArrowForwardIos, null, modifier = Modifier.size(14.dp), tint = MedColors.TextGray)
                    }
                }
            }
        }
    }
}

@Composable
fun QrDialog(data: String, onDismiss: () -> Unit) {
    val qrBitmap = remember(data) { QrHelper.generateQrBitmap(data) }
    Dialog(onDismissRequest = onDismiss) {
        Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(modifier = Modifier.padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Secure Handover", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MedColors.TextDark)
                Spacer(modifier = Modifier.height(24.dp))
                if (qrBitmap != null) Image(bitmap = qrBitmap.asImageBitmap(), contentDescription = null, modifier = Modifier.size(220.dp))
                Spacer(modifier = Modifier.height(24.dp))
                Button(onClick = onDismiss, shape = CircleShape, colors = ButtonDefaults.buttonColors(containerColor = MedColors.Primary)) { Text("Done") }
            }
        }
    }
}

@Composable
fun SectionHeader(title: String) { Text(title.uppercase(), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MedColors.TextGray, letterSpacing = 1.sp, modifier = Modifier.padding(bottom = 8.dp)) }
@Composable
fun formatVitalName(key: String): String { return key.replace(Regex("([A-Z])"), " $1").trim().split(" ").joinToString(" ") { it.replaceFirstChar { char -> char.uppercase() } } }
class ScribeViewModelFactory(private val context: android.content.Context) : androidx.lifecycle.ViewModelProvider.Factory { override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T { return ScribeViewModel(context) as T } }